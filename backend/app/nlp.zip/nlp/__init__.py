# Init for NLP package
