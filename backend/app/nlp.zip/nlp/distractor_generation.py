def generate_distractors(correct_answer, doc=None, entity_label=None, num_distractors=3):
    distractors = set()
    normalized_answer = correct_answer.lower().strip()

    # Handle numbers
    if correct_answer.replace(",", "").replace(".", "").isdigit():
        try:
            num = float(correct_answer.replace(",", ""))
            for diff in [-10, -5, 5, 10]:
                val = str(int(num + diff)) if num.is_integer() else str(round(num + diff, 2))
                if val != correct_answer:
                    distractors.add(val)
        except:
            pass

    # Named entity distractors
    if entity_label and doc:
        ents = [ent.text.strip() for ent in doc.ents if ent.label_ == entity_label and ent.text.strip().lower() != normalized_answer]
        distractors.update(ents[:num_distractors])

    # WordNet fallback
    if len(distractors) < num_distractors:
        for syn in wn.synsets(correct_answer):
            for lemma in syn.lemmas():
                word = lemma.name().replace("_", " ").title()
                if word.lower().strip() != normalized_answer and len(word.split()) <= 2:
                    distractors.add(word)
                if len(distractors) >= num_distractors:
                    break
            if len(distractors) >= num_distractors:
                break

    # Final fallback
    common = ["climate change", "pollution", "waste", "carbon", "greenhouse"]
    while len(distractors) < num_distractors:
        dummy = random.choice(common)
        if dummy.lower() != normalized_answer and dummy not in distractors:
            distractors.add(dummy)

    return list(distractors)[:num_distractors]
