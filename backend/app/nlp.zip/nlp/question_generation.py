from transformers import T5ForConditionalGeneration, T5Tokenizer
import re

MODEL_NAME = "valhalla/t5-small-qg-hl"

class QuestionGenerator:
    def __init__(self, model_name=MODEL_NAME):
        self.tokenizer = T5Tokenizer.from_pretrained(model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(model_name)

    def generate_question(self, context, answer):
        """
        Generate a question based on the context and highlighted answer.
        """
        # Ensure the answer is present in the context
        if answer not in context:
            raise ValueError("The answer must be a substring of the context.")

        # Highlight the first occurrence of the answer in the context
        highlighted_context = re.sub(re.escape(answer), f"<hl> {answer} <hl>", context, count=1)

        # Prepare the prompt
        prompt = f"generate question: {highlighted_context} </s>"

        # Tokenize the input
        input_ids = self.tokenizer.encode(prompt, return_tensors="pt")

        # Generate the question
        outputs = self.model.generate(
            input_ids,
            max_length=64,
            num_beams=4,
            early_stopping=True
        )

        # Decode the generated question
        question = self.tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
        return question

# Example usage
if __name__ == "__main__":
    context = "The capital of France is Paris, known for its art, gastronomy, and culture."
    answer = "Paris"
    qg = QuestionGenerator()
    question = qg.generate_question(context, answer)
    print("Generated Question:", question)
