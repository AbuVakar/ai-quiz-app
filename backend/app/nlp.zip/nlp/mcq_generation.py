import random
import spacy
from .question_generation import generate_question
from .distractor_generation import generate_distractors
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer

# Load models
nlp = spacy.load("en_core_web_sm")
embedder = SentenceTransformer('all-MiniLM-L6-v2')

def generate_mcqs(text, num_questions=10):
    mcqs = []
    doc = nlp(text)

    # Extract candidate answers
    candidates = [ent.text for ent in doc.ents if ent.label_ in {"PERSON", "ORG", "GPE"}]
    if len(candidates) < num_questions:
        candidates += [chunk.text for chunk in doc.noun_chunks]
    candidates = list(dict.fromkeys(candidates))[:num_questions]

    for candidate in candidates:
        context = ""
        entity_label = None

        for ent in doc.ents:
            if ent.text == candidate:
                entity_label = ent.label_
                break
        for sent in doc.sents:
            if candidate in sent.text:
                context = sent.text
                break
        if not context:
            context = text

        # Generate question
        question = generate_question(context, candidate)
        if not question or len(question) < 8 or not any(q_word in question.lower() for q_word in ["what", "who", "when", "where", "which", "why", "how"]):
            continue

        # Generate distractors
        distractors = generate_distractors(candidate, doc=doc, entity_label=entity_label)
        options = distractors + [candidate]
        options = list(set([opt.strip().capitalize() for opt in options if len(opt.strip()) > 2]))

        if len(options) < 4:
            while len(options) < 4:
                options.append(candidate + "_" + str(random.randint(10, 99)))

        random.shuffle(options)

        mcqs.append({
            "question": question,
            "options": options[:4],
            "answer": candidate
        })

    # Deduplicate questions
    unique_mcqs = []
    seen_embeddings = []
    for mcq in mcqs:
        q_embedding = embedder.encode([mcq["question"]])
        if not any(cosine_similarity(q_embedding, e)[0][0] > 0.85 for e in seen_embeddings):
            seen_embeddings.append(q_embedding)
            unique_mcqs.append(mcq)

    return unique_mcqs
